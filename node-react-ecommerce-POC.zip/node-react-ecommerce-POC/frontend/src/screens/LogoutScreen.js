import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom'
import axios from 'axios';
import { useSelector, useDispatch } from 'react-redux';
import { listProducts } from '../actions/productActions';
import { logout } from '../actions/userActions';

function LogoutScreen(props) {
  
  
  const dispatch = useDispatch();
  useEffect(() => {
    dispatch(logout());
    props.history.push("/");

    return () => {
       
      //
    }
  },[])

 

  return <div>
 
  </div>
  
  
    


}
export default LogoutScreen;